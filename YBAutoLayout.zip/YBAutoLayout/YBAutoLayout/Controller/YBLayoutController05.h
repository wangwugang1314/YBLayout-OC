//
//  YBLayoutController05.h
//  YBAutoLayout
//
//  Created by 王亚彬 on 2017/3/8.
//  Copyright © 2017年 王亚彬. All rights reserved.
//

#import "YBBaseController.h"

@interface YBLayoutController05 : YBBaseController

@end
