//
//  YBLayoutController07.h
//  YBAutoLayout
//
//  Created by 王亚彬 on 2017/3/9.
//  Copyright © 2017年 王亚彬. All rights reserved.
//

#import "YBBaseController.h"

@interface YBLayoutController07 : YBBaseController

@end
