//
//  YBBaseController.h
//  YBAutoLayout
//
//  Created by 王亚彬 on 2017/3/8.
//  Copyright © 2017年 王亚彬. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+YBLayout.h"

@interface YBBaseController : UIViewController

@property(nonatomic, strong) UIView *referenceView;

@property(nonatomic, strong) UIView *view0;
@property(nonatomic, strong) UIView *view1;
@property(nonatomic, strong) UIView *view2;
@property(nonatomic, strong) UIView *view3;
@property(nonatomic, strong) UIView *view4;
@property(nonatomic, strong) UIView *view5;
@property(nonatomic, strong) UIView *view6;
@property(nonatomic, strong) UIView *view7;
@property(nonatomic, strong) UIView *view8;
@property(nonatomic, strong) UIView *view9;
@property(nonatomic, strong) UIView *view10;
@property(nonatomic, strong) UIView *view11;
@property(nonatomic, strong) UIView *view12;
@property(nonatomic, strong) UIView *view13;
@property(nonatomic, strong) UIView *view14;
@property(nonatomic, strong) UIView *view15;

@end
